import React from 'react';
import './App.css';

export default function App() {
    return (
        <div>
            {/* Header Section */}
            <header className="header">
                <h1>Hari Chandana Kasula's Portfolio</h1>
                <div>
                    <a href="https://www.linkedin.com/in/hari-chandana-kasula/" target="_blank" rel="noopener noreferrer">LinkedIn</a>
                    <a href="https://github.com/harichandanakasula" target="_blank" rel="noopener noreferrer">GitHub</a>
                </div>
            </header>

            <div className="container">
                {/* Landing Section */}
                <section className="landing">
                    <img src="avatar.png" alt="Avatar" />
                    <h2>Hi, I'm Hari Chandana Kasula</h2>
                    <p>I am an MSCS student at Columbia University passionate about Machine Learning and Data Science.</p>
                </section>

                {/* Projects Section */}
                <section className="projects">
                    <div className="project-card">
                        <h3>Credit Card Fraud Detection</h3>
                        <p>Detects fraudulent credit card transactions using machine learning.</p>
                        <a href="https://github.com/harichandanakasula/Creditcard-fraud-detection" target="_blank" rel="noopener noreferrer">View Project</a>
                    </div>
                    <div className="project-card">
                        <h3>Plant Disease Detection</h3>
                        <p>Uses neural networks to identify plant diseases.</p>
                        <a href="https://github.com/harichandanakasula/PlantDiseasedetection_NeuralNetworks" target="_blank" rel="noopener noreferrer">View Project</a>
                    </div>
                    <div className="project-card">
                        <h3>Cancer Incidence Visualization</h3>
                        <p>Analyzes cancer incidence rates across U.S. counties.</p>
                        <a href="https://github.com/harichandanakasula/AML_Cancer" target="_blank" rel="noopener noreferrer">View Project</a>
                    </div>
                </section>

                {/* Contact Section */}
                <section className="contact">
                    <h2>Contact Me</h2>
                    <form className="contact-form">
                        <input type="email" placeholder="Your email" required />
                        <textarea placeholder="Your message" required></textarea>
                        <button type="submit">Send Message</button>
                    </form>
                </section>
            </div>
        </div>
    );
}
